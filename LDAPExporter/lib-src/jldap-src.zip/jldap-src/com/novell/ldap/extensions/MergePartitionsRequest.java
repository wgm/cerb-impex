/* **************************************************************************
 * $OpenLDAP: pkg/jldap/com/novell/ldap/extensions/MergePartitionsRequest.java,v 1.3 2003/08/21 10:40:19 kkanil Exp $
 *
 * Copyright (C) 2001 Novell, Inc. All Rights Reserved.
 *
 * THIS WORK IS SUBJECT TO U.S. AND INTERNATIONAL COPYRIGHT LAWS AND
 * TREATIES. USE, MODIFICATION, AND REDISTRIBUTION OF THIS WORK IS SUBJECT
 * TO VERSION 2.0.1 OF THE OPENLDAP PUBLIC LICENSE, A COPY OF WHICH IS
 * AVAILABLE AT HTTP://WWW.OPENLDAP.ORG/LICENSE.HTML OR IN THE FILE "LICENSE"
 * IN THE TOP-LEVEL DIRECTORY OF THE DISTRIBUTION. ANY USE OR EXPLOITATION
 * OF THIS WORK OTHER THAN AS AUTHORIZED IN VERSION 2.0.1 OF THE OPENLDAP
 * PUBLIC LICENSE, OR OTHER PRIOR WRITTEN CONSENT FROM NOVELL, COULD SUBJECT
 * THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
 ******************************************************************************/
package com.novell.ldap.extensions;

import com.novell.ldap.LDAPExtendedOperation;
import com.novell.ldap.LDAPException;
import com.novell.ldap.asn1.LBEREncoder;
import com.novell.ldap.asn1.ASN1Integer;
import com.novell.ldap.asn1.ASN1OctetString;
import com.novell.ldap.resources.ExceptionMessages;
import java.io.IOException;
import java.io.ByteArrayOutputStream;

/**
 *
 *  Merges a child partition with its parent partition.
 *
 *  <p>To merge a child partition with its parent, you must create an
 *  instance of this class and then call the extendedOperation method
 *  with this object as the required LDAPExtendedOperation parameter.</p>

 *
 *  <p>The mergePartitionsRequest extension uses the following OID:<br>
 *   &nbsp;&nbsp;&nbsp;2.16.840.1.113719.1.27.100.5</p>
 *
 *  <p>The requestValue has the following format:<br>
 *
 *  requestValue ::=<br>
 *  &nbsp;&nbsp;&nbsp;&nbsp;    flags &nbsp;&nbsp;&nbsp;  INTEGER<br>
 *  &nbsp;&nbsp;&nbsp;&nbsp;    dn &nbsp;&nbsp;&nbsp;     LDAPDN</p>
 */
public class MergePartitionsRequest extends LDAPExtendedOperation {

/**
 * Constructs an extended operation object for merging partitions.
 *
 * @param dn        The distinguished name of the child partition's root.
 *<br><br>
 * @param flags     Determines whether all servers in the replica ring must
 *                  be up before proceeding. When set to zero, the status of
 *                  the servers is not checked. When set to
 *                  LDAP_ENSURE_SERVERS_UP, all servers must be up for the
 *                  operation to proceed.
 *
 * @exception LDAPException A general exception which includes an error
 *                          message and an LDAP error code.
 */

    public MergePartitionsRequest(String dn,int flags) throws LDAPException{

        super(ReplicationConstants.MERGE_NAMING_CONTEXT_REQ, null);

        try {

            if (dn == null)
                throw new IllegalArgumentException(
                                         ExceptionMessages.PARAM_ERROR);

            ByteArrayOutputStream encodedData = new ByteArrayOutputStream();
            LBEREncoder encoder  = new LBEREncoder();

            ASN1Integer asn1_flags = new ASN1Integer(flags);
            ASN1OctetString asn1_dn = new ASN1OctetString(dn);

            asn1_flags.encode(encoder, encodedData);
            asn1_dn.encode(encoder, encodedData);

            setValue(encodedData.toByteArray());

        }
        catch(IOException ioe) {
            throw new LDAPException(ExceptionMessages.ENCODING_ERROR,
                                 LDAPException.ENCODING_ERROR,(String)null);
      }
   }
}
